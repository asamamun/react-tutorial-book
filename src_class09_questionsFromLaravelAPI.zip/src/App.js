import * as React from 'react';
import './App.css';
import RenderQuestions from './RenderQuestions';

const API_ENDPOINT = 'http://192.168.54.78/r49/laravel/projects/TigerQuiz/public/api/';
// const API_ENDPOINT = 'http://localhost/r49/laravel/projects/TigerQuiz/public/api/questions';

const App = () => {
  const [q,setq] = React.useState([]);
//run only once bcs the second argument is an empty array
// If you want to run an effect and clean it up only once (on mount and unmount), you can pass an empty array ([]) as a second argument. This tells React that your effect doesn’t depend on any values from props or state, so it never needs to re-run. This isn’t handled as a special case — it follows directly from how the dependencies array always works.
  React.useEffect(() => {
        
    fetch(`${API_ENDPOINT}questions`)
      .then((response) => response.json())
      .then((result) => {
        console.log(result);
        setq(result);
      });


  }, []);

  return (
    <div className='container'>
      <h1 id='questionslist'>Questions</h1>
      <form action={API_ENDPOINT+'answers'} method="post">
      <RenderQuestions questions={q} title='randomquestion'/>
      <input type='submit' className='btn btn-primary' value='Submit' name='submit'/>
      </form>
    </div>
  );
};


export default App;
