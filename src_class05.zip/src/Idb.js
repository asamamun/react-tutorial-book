import { Component } from 'react';
class Idb extends Component {
    state = {  } 
    render() { 
        return (
            <div>
                i am IDB component
            </div>
        );
    }
}
 
export default Idb;