/* function Idbbisew() {
    return ( 
        <div>
            <h1>I am IDBBISEW</h1>
        </div>
     );
} */

const Idbbisew = () => {
    //all my works and logics here
    let title = 'IDBBISEW 11';
    return (
        <div>
            <h1>I am {title}</h1>
            <label htmlFor="search">Search: </label>
            <input id="search" type="text" />
        </div>
    )
}
export default Idbbisew;